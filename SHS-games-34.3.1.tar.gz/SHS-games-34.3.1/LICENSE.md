# Copyright &copy; 2019-2022 [SHS Games](https://shsgames.github.io/)

## Application
SHS Games is available to everyone under the [GPL 3.0 License](https://www.gnu.org/licenses/gpl-3.0.en.html). This license states that redistribution is permitted given that the license stays the same. By redistributing SHS Games, you agree to the following:
1. You are responsible to respect the freedom of others.
2. Copyright & License information remain unmodified & are present in each copy.

---
## Games
All games that are available at any given time are NOT owned by SHS Games unless explicitly stated. Games are owned by various publishers and have been compiled from various sources.
